*********Thank you for using Heic File Converte command line tool********
This is Shane Steven. An independent software developer. Thank you for using my program. 
This is a free and 100% clean software. Enjoy it.
If you have any problems or want to learn how to use this command line,
please go to this page:
https://heicfile.com/command-line.html
or contact me via email: support@heicfile.com

